import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateCourseComponent } from './course/components/create-course/create-course.component';
import { InstructorCoursesComponent } from './course/components/instructor-courses/instructor-courses.component';

const routes: Routes = [
  { path: 'course/create', component: CreateCourseComponent },
  { path: 'course/instructor', component: InstructorCoursesComponent },
  { path: '', redirectTo: '/course/instructor', pathMatch: 'full' }, // Default route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
