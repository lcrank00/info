import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InstructorCoursesComponent } from './course/components/instructor-courses/instructor-courses.component'; // Import the new component
@NgModule({
  declarations: [
    AppComponent,
    InstructorCoursesComponent // Declare the new component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, // Include this
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
