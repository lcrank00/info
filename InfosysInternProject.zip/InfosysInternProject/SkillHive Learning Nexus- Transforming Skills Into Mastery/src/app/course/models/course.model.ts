export interface Course {
    id: number;
    courseId: string;
    courseName: string;
    instructor: string;
    startDate: string;
    endDate: string;
    technology: string;
    status: string;
  }
  