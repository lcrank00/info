import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { CourseRoutingModule } from './course-routing.module';
import { CreateCourseComponent } from './components/create-course/create-course.component';
import { InstructorCoursesComponent } from './components/instructor-courses/instructor-courses.component';

@NgModule({
  declarations: [CreateCourseComponent, InstructorCoursesComponent],
  imports: [CommonModule, ReactiveFormsModule, CourseRoutingModule],
})
export class CourseModule {}
