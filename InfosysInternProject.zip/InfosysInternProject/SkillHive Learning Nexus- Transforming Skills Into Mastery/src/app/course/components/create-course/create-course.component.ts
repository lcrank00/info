import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-course',
  templateUrl: './create-course.component.html',
  styleUrls: ['./create-course.component.css'],
})
export class CreateCourseComponent {
  courseForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.courseForm = this.fb.group({
      courseId: ['', Validators.required],
      courseName: ['', Validators.required],
      instructor: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      technology: ['', Validators.required],
      status: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.courseForm.valid) {
      console.log('Course Created:', this.courseForm.value);
      alert('Course Created Successfully!');
      this.courseForm.reset();
    }
  }
}
