import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructor-courses',
  templateUrl: './instructor-courses.component.html',
  styleUrls: ['./instructor-courses.component.css'],
})
export class InstructorCoursesComponent implements OnInit {
  courses = [
    { "id": 1, "name": "Angular Basics", "status": "Ongoing" },
    { "id": 2, "name": "React Fundamentals", "status": "Upcoming" },
    { "id": 3, "name": "JavaScript Essentials", "status": "Completed" }
  ];

  constructor() {}

  ngOnInit(): void {}
}
